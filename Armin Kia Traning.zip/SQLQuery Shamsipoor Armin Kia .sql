select * from Tb_Person;

insert into Tb_Person (F_NAME,L_NAME,NATIONAL_ID,AGE)
values
('ali','alipour',1111,20),
('mahdi','kargar',2222,21),
('armin','kia',3333,19),
('erfan','kargar',4444,20);

insert into Tb_Student(PERSON_ID,STUDENT_NUMBER)
values
(2,59211033154020),
(3,59211033154023);

select * from Tb_Student;

select Tb_Person.ID,Tb_Person.F_NAME,Tb_Person.L_NAME,
Tb_Student.STUDENT_NUMBER from Tb_Student full join Tb_Person
on Tb_Student.PERSON_ID=Tb_Person.ID;

select*from Tb_Person;
update Tb_Person set NATIONAL_ID=null where id=1;

select count(*) from Tb_Person
where age>=20;

select * from Tb_Payment;
select * from Tb_Student;

insert into Tb_Payment(STUDENT_ID,AMUNT,PAYMENT_DATE)
values
(2,3500,'2017-08-26');

select sum (AMUNT) from Tb_Payment where STUDENT_ID=2;

select avg (AMUNT) from Tb_Payment;

select * from Tb_Payment where PAYMENT_DATE>'2017-08-25 00:00:00.1';

select Tb_Person.L_NAME, sum (AMUNT) from Tb_Student join Tb_Payment
on Tb_Payment.STUDENT_ID=Tb_Student.ID
join Tb_Person on Tb_Student.PERSON_ID=PERSON_ID
group by Tb_Person.L_NAME;

select * from Vi_Feed where F_NAME like 'm%';

select x.* from
(

select Tb_Person.F_NAME,Tb_Person.L_NAME,Tb_Student.STUDENT_NUMBER 
from Tb_Student join Tb_Person on Tb_Student.PERSON_ID=Tb_Person.ID

)x;














